<?php
// config.php ejemplo
// Definir rutas base que use el paquete
define('BASE_DIR', __DIR__ . '/..');
define('BASE_URL', '/'); // ajustar según host

// Opcional: ajustes para mPDF
ini_set('display_errors', 1);
error_reporting(E_ALL);
